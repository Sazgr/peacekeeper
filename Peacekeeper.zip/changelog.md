## Peacekeeper Changelog
#### v0.1 - First (Mostly) UCI-compliant version
#### v0.2 - Bugfix: underpromotions in UCI format were interpreted as queen promotions
#### v0.3 - Bugfix: engine ran out of time before searching and returned the last played move
#### v0.4 - Zobrist hash is now kept on a stack
#### v0.5 - Added detection of 50-move and repetition draws
#### v0.6 - Bugfix: engine ran out of time when the time was low compared to the increment
#### v0.7 - Bugfix: half-move counter was not getting incremented after a quiet move
50-move draws are now working now
#### v0.8 - Removed some unnecessary zobrist updating in undo_move()
#### v0.9 - Bugfix: draw detection was not working
Actually no more draws now...
#### v0.10 - Bugfix: from-scratch zobrist generation was not handling en passant correctly
This should fix some transposition table weirdness
#### v0.11 - Bugfix: transposition table size was not constrained to a power of two
#### v0.12 - Move generation code is templated for easier maintanence and more speed
#### v0.13 - Bugfix: static evaluation in PVS routine was declared as a bool
I really don't know what happened here, that one thing was really decreasing the speed and the effectiveness of my search
#### v0.14 - Bugfix: engine ran out of time often