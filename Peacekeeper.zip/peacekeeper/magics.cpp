#include "magics.h"

u64 lookup_table[97264];