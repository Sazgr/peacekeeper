#ifndef PEACEKEEPER_TYPEDEFS
#define PEACEKEEPER_TYPEDEFS

#include <cstdint>

typedef std::uint64_t u64;

#endif